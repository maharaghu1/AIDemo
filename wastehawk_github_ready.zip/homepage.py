import streamlit as st
st.title('Welcome to WasteHawk Homepage')