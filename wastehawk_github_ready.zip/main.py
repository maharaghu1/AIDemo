import streamlit as st
st.switch_page('homepage.py')